package com.example.javaproto;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;

public class Obstacles extends RectF{
    public float sizx;
    private boolean isOut=false;
    public int lane=0;

    public Obstacles(float width, float size) {
        this.sizx=size;
        this.top=0;
        this.bottom=this.top+size;
        this.right=width-size/2;
        this.left=width+size/2;
    }

    public float getTop() {
        return top;
    }


    public void setPosition(float dim,int lane) {
        this.left = dim-sizx/2;
        this.right = dim+sizx/2;
        this.lane = lane;
    }

    public boolean isOut() {
        return isOut;
    }
    public void draw(Canvas canvas){
        RectF rectF1=new RectF(left,top,right,bottom);
        Paint paint = new Paint();
        paint.setStrokeWidth(10);
        paint.setColor(Color.GREEN);
        canvas.drawRect(rectF1,paint);
        if(canvas.getHeight()<top){
            isOut=true;
        }
    }
    public void updatePosition(){
        this.top+=10;
        this.bottom+=10;
    }

}
