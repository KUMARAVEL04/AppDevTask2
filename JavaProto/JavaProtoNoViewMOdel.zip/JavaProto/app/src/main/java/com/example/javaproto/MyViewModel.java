package com.example.javaproto;

import androidx.lifecycle.ViewModel;

public class MyViewModel extends ViewModel {
}
