package com.example.javaproto;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;

public class Character extends RectF{
    private int colDur=0;
    boolean isOut=false;
    public int getColDur() {
        return colDur;
    }
    public void setColDur(int colDur) {
        this.colDur = colDur;
    }
    public RectF afterImage;
    public Character() {
    }
    public Character(float left, float top, float right, float bottom) {
        super(left, top, right, bottom);
    }
    public void draw(Canvas canvas){
        RectF rectF1=new RectF(left,top,right,bottom);
        Paint paint = new Paint();
        paint.setStrokeWidth(10);
        paint.setColor(Color.GREEN);
        canvas.drawRect(rectF1,paint);
        if(canvas.getHeight()<top){
            isOut=true;
        }
    }

}
