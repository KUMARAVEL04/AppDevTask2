package com.example.javaproto;

import android.os.Bundle;
import android.os.Handler;
import android.view.View;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private Handler handler;
    private final long FPS = 1000/30;
    private Runnable run;
    private Boolean ifPause=false;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        myView canvasView = new myView(this);
        setContentView(canvasView);
        View decor_View = getWindow().getDecorView();

        int ui_Options = View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY;

        decor_View.setSystemUiVisibility(ui_Options);
        handler = new Handler();
        run = new Runnable() {
            @Override
            public void run() {
                canvasView.update(canvasView);
                if(canvasView.collision>1){
                    handler.removeCallbacksAndMessages(null);
                }
                ArrayList<Obstacles> ab = canvasView.getObsList();
                if(ab.size()<15&&ab.size()>0){
                    if(ab.get(ab.size()-1).getTop()>canvasView.getHeight()*0.2f) {
                        canvasView.addObstacle();
                    }
                }
                if(!ifPause)
                    handler.postDelayed(this, FPS);
            }
        };
    }

    @Override
    protected void onResume() {
        super.onResume();
        ifPause=false;
        handler.postDelayed(run,1000/30);
    }

    @Override
    protected void onPause() {
        super.onPause();
        ifPause=true;
    }
}