package com.example.javaproto;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.media.MediaPlayer;
import android.view.MotionEvent;
import android.view.View;

import androidx.annotation.NonNull;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Random;

public class myView extends View {
    Paint paint1,paint2,paint3;
    int a=0;
    int b=0;
    boolean ifStart=true;
    Character jerry;
    Tom tom;
    float[] widths = new float[4];
    ArrayList<Obstacles> obsList = new ArrayList<>();
    int collision=0;
    boolean immFram=true;
    boolean cutscene = true;

    public myView(Context context) {
        super(context);
        obsList.clear();
        paint1 = new Paint();
        paint1.setColor(Color.parseColor("#f9eee0"));
        paint1.setStrokeWidth(10);
        paint2 = new Paint();
        paint2.setColor(Color.parseColor("#e5dccd"));
        paint2.setStrokeWidth(10);
        paint3 = new Paint();
        paint3.setColor(Color.BLACK);
        paint3.setStrokeWidth(10);
    }
    public void drawBoundingBox() {
        // Refresh the view by calling onDraw function
        invalidate();
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        Paint paint3 = new Paint();
        paint3.setColor(Color.BLACK);
        paint3.setStrokeWidth(10);
        float width = widths[1]*2;
        if(0<=event.getX()&&event.getX()<width/2){
            a--;
            if(a>-2){
                jerry.offset(-width*5/16,0);
            }
            else{
                a++;
            }
        }
        else{
            a++;
            if(a<2){
                jerry.offset(width*5/16,0);
            }
            else{
                a--;
            }
        }
        return super.onTouchEvent(event);
    }

    @Override
    public void onDraw(@NonNull Canvas canvas) {
        float width = canvas.getWidth();
        widths[1]=width/2;
        widths[0]=width*3/16;
        widths[2]=width*13/16;
        widths[3]=canvas.getHeight();
        float newWidth = width/4;
        float smallWidth = newWidth/4;
        canvas.drawColor(Color.parseColor("#e5dccd"));
        canvas.drawRect(smallWidth,0,newWidth+smallWidth,getHeight(),paint1);
        canvas.drawRect(newWidth+smallWidth*2,0,newWidth*2+smallWidth*2,getHeight(),paint1);
        canvas.drawRect(newWidth*2+smallWidth*3,0,newWidth*3+smallWidth*3,getHeight(),paint1);
        if(ifStart){
            ifStart=!ifStart;
            addObstacle();
            jerry = new Character(width/2-smallWidth,getHeight()*0.7f-smallWidth,width/2+smallWidth,getHeight()*0.7f+smallWidth);
            tom = new Tom(width/2-width/8,getHeight()*0.9f-width/8,width/2+width/8,getHeight()*0.9f+width/8);
        }
        Paint paint4 = new Paint();
        paint4.setColor(Color.WHITE);
        paint4.setStyle(Paint.Style.STROKE);
        paint4.setStrokeWidth(2);
        canvas.drawRect(jerry,paint4);
        canvas.drawCircle(jerry.centerX(), jerry.centerY(),smallWidth,paint3);
        if(collision>0){
            canvas.drawRect(tom, paint4);
            canvas.drawCircle(tom.centerX(), tom.centerY(), smallWidth * 2, paint3);
        }
        for (Obstacles obstacle : obsList) {
            obstacle.draw(canvas);
        }
        super.onDraw(canvas);
    }

    public void update(myView view) {
        Iterator<Obstacles> iterator1 = obsList.iterator();
        while(iterator1.hasNext()){
            iterator1.next().updatePosition();
        }
        Iterator<Obstacles> iterator = obsList.iterator();
        while(iterator.hasNext()){
            if(iterator.next().isOut()){
                iterator.remove();
            }
        }
        boolean move = false;
        boolean right = b != 1;
        boolean left = b != -1;
        Iterator<Obstacles> iteratorx = obsList.iterator();
        int x=0;
        System.out.println(b);
        while(iteratorx.hasNext()){
            Obstacles ab = iteratorx.next();
            if(ab.centerX()==tom.centerX()&& ab.bottom>tom.top*0.85f){
                move=true;
            }
            x++;
            if(x>1){
                break;
            }
        }
        Iterator<Obstacles> iteratorx1 = obsList.iterator();
        int ind=0;
        if(move){
            while(iteratorx1.hasNext()){
                Obstacles ab = iteratorx1.next();
                System.out.println(ab.lane);
                ind++;
                if(ind>2){
                    break;
                }
                if(ab.lane==b-1){
                    System.out.println("RIGHT");
                    left=false;
                }
                if(ab.lane==b+1){
                    System.out.println("LEFT");
                    right=false;
                }
            }
        }
        else{
            right=false;
            left=false;
        }
        if(left){
            b--;
            if(b>-2){
                tom.offset(-view.getWidth()*5/16,0);
            }
            else{
                b++;
            }
        }
        else if(right){
            b++;
            if(b<2){
                tom.offset(view.getWidth()*5/16,0);
            }
            else{
                b--;
            }
        }

        Iterator<Obstacles> iterator2 = obsList.iterator();
        while(iterator2.hasNext()&& jerry.getColDur()==0){
            if(iterator2.next().intersect(jerry)){
                final MediaPlayer mp = MediaPlayer.create(getContext(), R.raw.wrong);
                mp.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                    public void onCompletion(MediaPlayer mp) {
                        mp.release();
                    }
                });
                mp.start();
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
                iterator2.remove();
                jerry.setColDur(100);
                collision++;
            }
        }
        if(collision>1){

        }
        if(jerry.getColDur()>0) {
            jerry.setColDur(jerry.getColDur() - 1);
            if(jerry.getColDur()%10==0){
                if (immFram) {
                    paint3.setColor(Color.parseColor("#DD3D3D3D"));
                }
                else{
                    paint3.setColor(Color.BLACK);
                }
                immFram=!immFram;
            }
        }
        else{
            paint3.setColor(Color.BLACK);
            immFram=true;
        }
        invalidate();
    }
    public void addObstacle(){
        Random rand = new Random();
        int x = rand.nextInt(1)+1;
        for(int i=0;i<x;i++) {
            Obstacles ab = new Obstacles(widths[1], 120);
            int randInt = rand.nextInt(5) % 3;
            if (randInt == 1) {
                ab.setPosition(widths[0],-1);
            } else if (randInt == 2) {
                ab.setPosition(widths[1],0);
            } else {
                ab.setPosition(widths[2],1);
            }
            obsList.add(ab);
        }
    }

    public ArrayList<Obstacles> getObsList() {
        return obsList;
    }
}
