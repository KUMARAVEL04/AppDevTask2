package com.example.javaproto;

import android.graphics.RectF;

public class Tom extends Character{
    public RectF afterImage1,afterImage2,afterImage3;

    public Tom(float left, float top, float right, float bottom) {
        super(left, top, right, bottom);
        afterImage1= new RectF(left,2*top-bottom,right,bottom);
    }


    public void setAfterImage(float width) {
        this.afterImage1.left -= width;
        this.afterImage1.right += width;
    }

    public RectF getAfterImage3() {
        return afterImage3;
    }

    public void setAfterImage3(RectF afterImage3) {
        this.afterImage3 = afterImage3;
    }
}
